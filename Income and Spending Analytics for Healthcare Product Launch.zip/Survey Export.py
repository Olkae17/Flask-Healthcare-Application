from pymongo import MongoClient
import csv

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client['surveyDB']
collection = db['responses']

# User class to hold and process survey data
class User:
    def __init__(self, name, age, gender, income, expenses):
        self.name = name
        self.age = age
        self.gender = gender
        self.income = income
        self.expenses = expenses

    def total_expense(self):
        return sum(self.expenses.values())

# Fetch data from MongoDB
users = []
for doc in collection.find():
    user = User(
        name=doc.get('name'),
        age=doc.get('age'),
        gender=doc.get('gender'),
        income=doc.get('income'),
        expenses=doc.get('expenses', {})
    )
    users.append(user)

# Export to CSV
csv_filename = "survey_data.csv"
with open(csv_filename, mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(['Name', 'Age', 'Gender', 'Income', 'Total Expenses', 'Expenses Detail'])

    for user in users:
        writer.writerow([
            user.name,
            user.age,
            user.gender,
            user.income,
            user.total_expense(),
            user.expenses
        ])

print(f"✅ Data exported successfully to {csv_filename}")
